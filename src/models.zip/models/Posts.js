const mongoose = require('mongoose')

const Schema = mongoose.Schema



const PostSchema = new Schema({

    title: String,
    mainDescription: String,    
    secDescription: String,
    idUser: {type: Schema.ObjectId, ref: 'User'} ,
    kudos:String,
    counterVisits:Number,
    idPostTemplate:String,    
    namePostTemplate:String,
    tag:String,
    createAt:Date,
    comments: [{
        idUser:{type: Schema.ObjectId, ref: 'User'} ,   
        comment:String,
        deleteUserId: String    
    }]
    
})
module.exports = mongoose.model ('posts', PostSchema)