const mongoose = require('mongoose')

const User = mongoose.model('User', {
    user: String,
    name: String,
    lastName: String,
    email: String,
    password: String,
    city: String,
    country: String,
    kudos: Number, 
    createAt: Date,
    about: String,
    followers: Array,
    following: Array,
    titleTimeLine: String

})

module.exports = User